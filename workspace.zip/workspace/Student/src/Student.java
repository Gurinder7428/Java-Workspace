
public class Student {

	
	public static String marks(int number)
	{
		if(number>=60)
			return "Pass";
		else return "Fail";
			
	}
	
	public static String result(int num)
	{
		if(num>=90 && num<100)
			return "A";
		else if(num>=80 && num<89)
			return "B";
		else if(num>=70 && num<79)
			return "C";
		else if(num>=60 && num<69)
			return "D";
		else return "Work Hard!!!!Aukha tera";
			
	}
	
	
}
