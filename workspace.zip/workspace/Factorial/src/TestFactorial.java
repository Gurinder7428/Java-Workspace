import static org.junit.Assert.*;

import org.junit.Test;

public class TestFactorial {

	@Test
	public void testFindFactorial() {
		assertEquals(120,Factorial.findFactorial(5));
		assertEquals(24,Factorial.findFactorial(4));
		assertEquals(6,Factorial.findFactorial(3));
	}

}
