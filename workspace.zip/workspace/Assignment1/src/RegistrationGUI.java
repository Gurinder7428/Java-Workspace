import javax.swing.*;
import java.awt.event.*;
import java.awt.*;


import javax.swing.*;
public class RegistrationGUI extends JFrame implements ActionListener{


	
	JPanel Panel1,Panel2,Panel3,Panel4,Panel5,Panel6,Panel7;
	JLabel lblName, lblQual, lblLanguages,lblexperience,lblyear,lblSalary;
	JTextField txtName,txtYear, txtSalary;
	JRadioButton button1,button2,button3;
	JRadioButton button4,button5;
	
	JCheckBox checkbox1,checkbox2,checkbox3,checkbox4,checkbox5;
	JButton buttonSubmit;
	final int width = 350;
	final int height = 600;

	public RegistrationGUI(){
	setTitle("Registration");
	setSize(width,height);
	setLayout(new GridLayout(7, 1));

	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	panelBuild();
	add(Panel1);
	add(Panel2);
	add(Panel3);
	add(Panel4);
	add(Panel5);
	add(Panel6);
	add(Panel7);
	setVisible(true);
	}
	private void panelBuild() {
	Panel1 = new JPanel();
	Panel2 = new JPanel();
	Panel3 = new JPanel();
	Panel4 = new JPanel();
	Panel5 = new JPanel();
	Panel6 = new JPanel();
	Panel7 = new JPanel();
	lblName= new JLabel("Enter Yor Name");
	lblQual = new JLabel(" Enter Qualification");
	lblLanguages= new JLabel(" Select Languages");
	lblexperience= new JLabel("Enter Experience");
	lblyear= new JLabel("Experience Year");
	lblSalary= new JLabel("Yor Salary is");

	txtName=new JTextField(10);
	button1 = new JRadioButton("PhD");
	button2 = new JRadioButton("Master");
	button3 = new JRadioButton("Bachlor");
	ButtonGroup group = new ButtonGroup();
	group.add(button1);
	group.add(button2);
	group.add(button3);

	checkbox1= new JCheckBox("English");
	checkbox2= new JCheckBox("French");
	checkbox3= new JCheckBox("Spanish");
	checkbox4= new JCheckBox("Hindi");
	checkbox5= new JCheckBox("portugues");

	button4 = new JRadioButton("Fresh graduated");
	button5 = new JRadioButton("Expert");
	ButtonGroup group1 = new ButtonGroup();
	group1.add(button4);
	group1.add(button5);
	txtYear=new JTextField(10);
	txtSalary=new JTextField(10);
	buttonSubmit= new JButton("Submit");
	button1.addActionListener(this);
	button2.addActionListener(this);
	button3.addActionListener(this);
	checkbox1.addActionListener(this);
	checkbox2.addActionListener(this);
	checkbox3.addActionListener(this);
	checkbox4.addActionListener(this);
	checkbox5.addActionListener(this);
	button4.addActionListener(this);
	button5.addActionListener(this);
	buttonSubmit.addActionListener(this);
	Panel1.add(lblName);
	Panel1.add(txtName);
	Panel2.add(lblQual);
	Panel2.add(button1);
	Panel2.add(button2);
	Panel2.add(button3);
	Panel3.add(lblLanguages);
	Panel3.add(checkbox1);
	Panel3.add(checkbox2);
	Panel3.add(checkbox3);
	Panel3.add(checkbox4);
	Panel3.add(checkbox5);
	Panel4.add(lblexperience);
	Panel4.add(button4);
	Panel4.add(button5);
	Panel5.add(lblyear);
	Panel5.add(txtYear);
	Panel6.add(lblSalary);
	Panel6.add(txtSalary);
	Panel7.add(buttonSubmit);

	Panel5.setVisible(false);
	}
	public static void main(String[] args) {

	new RegistrationGUI();
	}
	@Override
	public void actionPerformed(ActionEvent e) {
	double year;
	double languageSalary = 0;
	double salary=0;
	if(button5.isSelected()){
	Panel5.setVisible(true);


	}else{
	Panel5.setVisible(false);
	}
	double count=0;
	if(checkbox1.isSelected()){
	count++;
	}
	if(checkbox2.isSelected()){
	count++;
	}
	if(checkbox3.isSelected()){
	count++;
	}
	if(checkbox4.isSelected()){
	count++;
	}
	if(checkbox5.isSelected()){
	count++;
	}
	if(count>1){
	languageSalary=count*100;
	}
	if(e.getSource()==buttonSubmit){
	if(button5.isSelected()){
	if(txtYear.getText().equals("")){
	JOptionPane.showMessageDialog(null, "Enter the number of experience years");
	}
	else{
	year=Double.parseDouble(txtYear.getText());
	salary=100*year;
	if(button1.isSelected()){
	salary=salary+6500+languageSalary;

	Double r= new Double(salary);
	txtSalary.setText(r.toString());

	}else if(button2.isSelected()){
	salary=salary+5800+languageSalary;
	Double r= new Double(salary);
	txtSalary.setText(r.toString());


	}else if(button3.isSelected()){
	salary=salary+5000+languageSalary;
	Double r= new Double(salary);
	txtSalary.setText(r.toString());


	}
	}
	}
	else{if(button1.isSelected()){
	salary=6500+languageSalary;
	Double r= new Double(salary);
	txtSalary.setText(r.toString());


	}else if(button2.isSelected()){
	salary=5800+languageSalary;
	Double r= new Double(salary);
	txtSalary.setText(r.toString());

	}else if(button3.isSelected()){
	salary=5000+languageSalary;
	Double r= new Double(salary);
	txtSalary.setText(r.toString());
	}
	}
	}
	}

	}