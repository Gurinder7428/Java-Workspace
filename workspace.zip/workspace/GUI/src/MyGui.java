import java.awt.Color;
import java.awt.event.*;

import javax.swing.*;
public class MyGui extends JFrame implements ActionListener{
JPanel panel;
JLabel lblMessage, lblResult;
JTextField tfDistance, tfResult;
JButton btnCalc, btnCalc2, btnClear;
final int width = 350;
final int height = 250;
//constructor

public MyGui(){
	setTitle("Kilo meter converter");
	setSize(width,height);
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	buildPanel();
	add(panel);
	
    setVisible(true);
}
public void buildPanel()
{
	//create components
	panel = new JPanel();
	panel.setBackground(Color.CYAN);
	lblMessage = new JLabel("Distance");
	lblResult = new JLabel("Miles");
	lblMessage.setForeground(Color.RED);
	lblResult.setForeground(Color.RED);
	tfDistance = new JTextField(10);
	tfResult = new JTextField(10);
	btnCalc= new JButton("KM to Mile");
	btnCalc.setBackground(Color.YELLOW);
	btnCalc.setForeground(Color.BLUE);
	btnCalc.addActionListener(this);
	btnCalc2= new JButton("Mile to KM");
	btnCalc2.setBackground(Color.YELLOW);
	btnCalc2.setForeground(Color.BLUE);
	btnCalc2.addActionListener(this);
	btnClear= new JButton("Clear");
	btnClear.setBackground(Color.YELLOW);
	btnClear.setForeground(Color.BLUE);
	btnClear.addActionListener(this);
	
	//adding components to the panel
	panel.add(lblMessage);
	panel.add(tfDistance);
	panel.add(lblResult);
	panel.add(tfResult);
	panel.add(btnCalc);
	panel.add(btnCalc2);
	panel.add(btnClear);
	
	
}
public static void main(String args[]){
	new MyGui();
}
@Override
public void actionPerformed(ActionEvent e) {
	// TODO Auto-generated method stub
	double miles, km;
	if (e.getSource()==btnCalc){
		if(tfDistance.getText().equals(""))
			JOptionPane.showMessageDialog(null, "Pease enter the Km");
		else{
			 km=Double.parseDouble(tfDistance.getText());
			 miles = km*0.6214;
			Double r = new Double(miles);
			tfResult.setText(r.toString());}
		}
	else if(e.getSource()==btnCalc2)
	{
		if(tfResult.getText().equals(""))
			JOptionPane.showMessageDialog(null, "Pease enter the Miles");
		else 
		{
			 miles = Double.parseDouble(tfResult.getText());
			 km = miles/0.6214;
			 Double k = new Double(km);
			 tfDistance.setText(k.toString());
		}
	}
	else
	{
		tfDistance.setText("");
		tfResult.setText("");
	}
	
}


}