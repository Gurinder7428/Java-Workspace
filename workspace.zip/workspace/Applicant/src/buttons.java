
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class buttons extends JFrame implements ActionListener,ItemListener {


private JPanel panel;
private JPanel panel1;
private JPanel panel2;
private JPanel panel3;
private JPanel panel4;
private JPanel panel5;
public String years;
public int count=0;
public int result=0;
private JLabel name;
private JLabel lblyears;
private JLabel qualification;
private JLabel lbllang;
private JLabel lbllevel;
private JTextField txtname;
private JTextField txtyears;
private JRadioButton phdbutton,masterbutton,bachelorbutton,freshbutton,expertbutton;
private JCheckBox engCheckBox,frCheckBox,spCheckBox,hinCheckBox,porCheckBox;
private ButtonGroup radioButtonGroup1;
private ButtonGroup radioButtonGroup2;
private final int WINDOW_WIDTH = 400; // Window width
private final int WINDOW_HEIGHT = 400;



public buttons()
{
setTitle("USe of radio buttons");
setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
setLayout(new GridLayout(5, 1));
buildPanel();
add(panel);

add(panel2);
add(panel3);
add(panel4);

setVisible(true);
panel1.setVisible(true);
panel2.setVisible(true);
panel3.setVisible(true);
panel4.setVisible(true);

}
private void buildPanel()
{
name=new JLabel("Enter applicant's name");
txtname=new JTextField(10);

qualification=new JLabel("Choose applicant's qualification");
phdbutton = new JRadioButton("PHD");
masterbutton = new JRadioButton("Master's");
bachelorbutton = new JRadioButton("Bachelor");
radioButtonGroup1 = new ButtonGroup();
 radioButtonGroup1.add(masterbutton);
radioButtonGroup1.add(bachelorbutton);
radioButtonGroup1.add(phdbutton);
masterbutton.addActionListener(this);
bachelorbutton.addActionListener(this);
phdbutton.addActionListener(this);

lbllang=new JLabel("Choose language");
engCheckBox = new JCheckBox("English");
frCheckBox = new JCheckBox("French");
spCheckBox = new JCheckBox("Spanish");
hinCheckBox = new JCheckBox("Hindi");
porCheckBox = new JCheckBox("Portuguese");
engCheckBox.addItemListener(this);
frCheckBox.addItemListener(this);
spCheckBox.addItemListener(this);
hinCheckBox.addItemListener(this);
porCheckBox.addItemListener(this);

lbllevel=new JLabel("Choose Expertise");
freshbutton = new JRadioButton("Fresh Graduated");
expertbutton = new JRadioButton("Expert");

panel = new JPanel();
panel.add(name);
panel.add(txtname);

panel2 = new JPanel();
panel2.add(qualification);
panel2.add(masterbutton);
panel2.add(bachelorbutton);
panel2.add(phdbutton);

panel3 = new JPanel();
panel3.add(lbllang);
panel3.add(engCheckBox);
panel3.add(frCheckBox);
panel3.add(spCheckBox);
panel3.add(hinCheckBox);
panel3.add(porCheckBox);

panel4 = new JPanel();
panel4.add(lbllevel);
panel4.add(freshbutton);
panel4.add(expertbutton);
radioButtonGroup2 = new ButtonGroup();
 radioButtonGroup2.add(freshbutton);
 radioButtonGroup2.add(expertbutton);
 
 lblyears=new JLabel("Enter experience years");
txtyears=new JTextField("0" ,10);
panel5=new JPanel();
 panel5.add(lblyears);
 panel5.add(txtyears);
 
 

}





public static void main(String[] args) {
// TODO Auto-generated method stub
new buttons();


}

@Override
public void actionPerformed(ActionEvent e)
{
if (e.getSource() == masterbutton)
{
result=5800;
}
else if (e.getSource() == bachelorbutton)
{
result=5000;
}
else if (e.getSource() == phdbutton)
{
result=6500;

}
//JOptionPane.showMessageDialog(null,"salary is "+result );


else if (e.getSource() == freshbutton )
{

panel5.setVisible(false);


}
else if (e.getSource() == expertbutton)
{

panel5.setVisible(true);

}
JCheckBox[] boxes = {engCheckBox,frCheckBox,spCheckBox,hinCheckBox,porCheckBox};
{
    for(int i = 0; i < boxes.length; ++i)
    {
        if(boxes[i].isSelected())
        {
            ++count;
int val=100;
int y=Integer.parseInt(years);
int ans=100*y;
int ans2=100*count;
JOptionPane.showMessageDialog(null, "experience years"+y+"value for this years"+ans+"languages known"+ count +"value is"+ans2);

        }
    }
}
}
@Override
public void itemStateChanged(ItemEvent e) {
	// TODO Auto-generated method stub
	
}

}




