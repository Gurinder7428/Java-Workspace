import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.*;

import javax.swing.*;
public class applicantInfo extends JFrame implements ActionListener {
	JPanel panel,panel1;
	JLabel lblName,lblQual,lblLanguage,lblExperience,lblTest;
	JTextField txtName;
	JButton btnCalc;
	JRadioButton radio1,radio2,radio3,radio4,radio5;
	JCheckBox box1,box2,box3,box4,box5;
	final int width = 200;
	final int height = 550;
	
	public applicantInfo(){
		setTitle("Registration Page");
		setSize(width,height);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		buildPanel();
		add(panel);
		
		add(panel1);
		panel1.setVisible(false);
		
	    setVisible(true);
	}
	
	public void buildPanel()
	{
		panel = new JPanel();
		panel.setBackground(Color.WHITE);
		lblName = new JLabel("Enter your Name");
		lblQual = new JLabel("Select Your Qualification");
		lblLanguage = new JLabel("Choose Your Languages");
		lblExperience = new JLabel("Select the below option");
		lblTest = new JLabel("Select the lblTest");
		
		panel1=new JPanel();
		panel1.add(lblTest);
		
		txtName = new JTextField(10);
		
		

		  radio1 = new JRadioButton("PhD.",
				   true);
         radio2 = new JRadioButton("Master");
         radio3 = new JRadioButton("Bachelor");
         
     
          ButtonGroup group = new ButtonGroup();
          group.add(radio1);
          group.add(radio2);
          group.add(radio3);
          
          radio4 = new JRadioButton("Fresher");
          radio5 = new JRadioButton("Expert");
          
          ButtonGroup group1 = new ButtonGroup();
          group1.add(radio4);
          group1.add(radio5);
          

          box1 = new JCheckBox("English");
          box2 = new JCheckBox("French");
          box3= new JCheckBox("Spanish");
          box4 = new JCheckBox("Hindi");
          box5 = new JCheckBox("Portguese");
         

		panel.add(lblName);
		panel.add(txtName);
		panel.add(lblQual);
		panel.add(radio1);
		panel.add(radio2);
		panel.add(radio3);
		panel.add(lblLanguage);
		panel.add(box1);
		panel.add(box2);
		panel.add(box3);
		panel.add(box4);
		panel.add(box5);
		panel.add(lblExperience);
		panel.add(radio4);
		panel.add(radio5);
		
		
		
		
	}
	
	public static void main(String args[]){
		new applicantInfo();
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		int result = 0;
		if (radio5.isSelected())
		{
			panel1.setVisible(true);
		}
		if (radio1.isSelected())
		{
		result=5800;
		}
		else if (radio2.isSelected())
		{
		result=5000;
		}
		else if (radio3.isSelected())
		{
		result=6500;

		}
		JOptionPane.showMessageDialog(null,"salary is "+result );
		
		if (box1.isSelected())
		{
		result +=100;
		}
		else if  (box2.isSelected())
		{
		result +=100;
		}
		else if  (box3.isSelected())
		{
		result +=100;
		}
		else if (box4.isSelected())
		{
		result +=100;
		}
		else if  (box5.isSelected())
		{
		result +=100;
		}
		

		
	}

}
