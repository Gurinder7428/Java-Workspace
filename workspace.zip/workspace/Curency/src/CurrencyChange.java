import java.util.Scanner;

public class CurrencyChange {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter currency amount in CAD: ");
		int amt = Integer.parseInt(sc.nextLine());
		
		System.out.println("Choose the currency in Which you want to Convert ? ");
		
		System.out.println("1:USD \t2:EURO \t3:RUPEE");
		double option = sc.nextInt();
		
		
		if (option == 1) {
			
			double dollar = amt * 0.76;
			System.out.println("Your " + amt + "$ in USD is : " + dollar + " Dollar");
			
		}
		
		else if (option == 2) {
			
			double dollar = amt * 0.68;
			System.out.println("Your " + amt + "$ in Euro is : " + dollar + " Euro");
			
		}
		
       else if (option == 3) {
			
			double dollar = amt * 53.73;
			System.out.println("Your " + amt + "$ in Rupees is : " + dollar + " rupee");
			
		}
       else {
			System.out.println("Wrong Choice");
		}

	}

}
