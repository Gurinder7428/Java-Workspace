import static org.junit.Assert.*;

import org.junit.Test;

public class TestCurrency {

	@Test
	public void testAskForAmount() {
		assertEquals("Enter the amount in CAD",Currency.askForAmount());
	}
	
	@Test
	public void testCheckUserChoice() {
		assertEquals("Wrong choice",Currency.checkUserChoice(8));
		assertEquals("Ok",Currency.checkUserChoice(1));
	}
	
	@Test
	public void testConvert() {
		assertEquals(380,Currency.Convert(1, 500));
		assertEquals(544,Currency.Convert(2, 800));
		//assertEquals(53700,Currency.Convert(3, 1000));
	}
	
	@Test
	public void testCheckMenu() {
		assertEquals("1. USD \n2. Euro \n3' Rupee",Currency.ShowMenu());
	}
	
	

	
	
	
	
}
