
public class Currency {
	
	public static String askForAmount(){
		return "Enter the amount in CAD";
		}
		public static String ShowMenu(){
		return "1. USD \n2. Euro \n3' Rupee";

		}
		
		public static String checkUserChoice(int choice){
		if(choice<1 ||choice>3)
		return "Wrong choice";
		else
		return "Ok";
		}
		
		public static int Convert(int choice, int cad){
		double result;
		if(choice==1)
		result = cad * 0.76;
		else if(choice==2)
		result= cad*0.68;
		
		else 
		result= cad*53.73;
		
		return (int) result;
		

		
	
	
	
		}
}
